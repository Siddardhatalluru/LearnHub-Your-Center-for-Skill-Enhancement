import { Link } from 'react-router-dom';

const CourseCard = ({ course }) => (
  <div className="border rounded-xl shadow p-4 hover:shadow-md transition">
    <img src={course.imageUrl} alt={course.title} className="w-full h-40 object-cover rounded-md mb-2" />
    <h2 className="text-xl font-semibold">{course.title}</h2>
    <p className="text-sm text-gray-600">{course.author}</p>
    <Link to={`/course/${course._id}`} className="text-blue-500 mt-2 block">View Course</Link>
  </div>
);

export default CourseCard;