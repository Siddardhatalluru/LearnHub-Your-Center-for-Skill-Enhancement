import { useParams } from 'react-router-dom';
import { useEffect, useState } from 'react';
import axios from 'axios';

const CourseDetail = () => {
  const { id } = useParams();
  const [course, setCourse] = useState(null);

  useEffect(() => {
    axios.get(`http://localhost:5000/api/courses`)
      .then(res => {
        const found = res.data.find(c => c._id === id);
        setCourse(found);
      });
  }, [id]);

  if (!course) return <div>Loading...</div>;

  return (
    <div className="p-4">
      <img src={course.imageUrl} alt={course.title} className="w-full h-60 object-cover rounded mb-4" />
      <h1 className="text-3xl font-bold">{course.title}</h1>
      <p className="text-gray-700 mt-2">{course.description}</p>
      <p className="mt-2 text-sm text-gray-500">By {course.author}</p>
    </div>
  );
};

export default CourseDetail;